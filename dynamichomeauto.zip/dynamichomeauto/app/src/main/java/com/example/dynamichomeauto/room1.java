package com.example.dynamichomeauto;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class room1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room1);
    }
}
